#include "enhanced_ino.hpp"

int test1(int a){
    return a;
}