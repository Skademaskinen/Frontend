#ifndef ENHANCED_INO_HPP
#define ENHANCED_INO_HPP

#include <Arduino.h>

#define main void loop(){}void setup
#define endl "\n"

int test1(int a);

template<typename T>
Print& operator<<(Print& serial, T value){serial.print(value);return serial;}

#endif