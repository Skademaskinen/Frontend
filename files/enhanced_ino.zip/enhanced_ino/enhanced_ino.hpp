#ifndef ENHANCED_INO_HPP
#define ENHANCED_INO_HPP

#include <Arduino.h>

#define main void loop(){}void setup
#define endl "\n"

int test1(int a);

template<typename T>
Print& operator<<(Print& serial, T value){
    serial.print(value);
    return serial;
}

template<typename T2>
class dynamic_array{
    private:
    T2* internal_array;
    int capacity;
    int logical_size;
    public:
    dynamic_array(T2 values[], int initial_size){
        internal_array = (T2*) malloc(sizeof(T2) * initial_size);
        capacity = initial_size;
        for(int i = 0; i < initial_size; i++){
            internal_array[i] = values[i];
            logical_size++;
        }
    }
    dynamic_array(){
        internal_array = (T2*) malloc(sizeof(T2) * 2);
        capacity = 2;
        logical_size = 0;
    }
    int get_length(){return logical_size;}
    void append(T2 value){
        if(logical_size == capacity){
            internal_array = (T2*) realloc(internal_array, sizeof(T2) * logical_size);
            capacity = capacity * 2;
        }
        internal_array[logical_size] = value;
        logical_size++;
    }

    T2 operator[](int index){return internal_array[index];}
};

template<typename T2>
Print& operator<<(Print& printer, dynamic_array<T2> array){
    printer.print("[");
    printer.print(array[0]);
    for(int i = 1; i < array.get_length(); i++){
        printer.print(", ");
        printer.print(array[i]);
    }
    printer.print("]");
    return printer;
}


//get the length of an iterable in amount of items rather than size in bytes with sizeof
template<int size, typename T4>
int length(T4 (&array)[size]){
    return size;
}



#endif